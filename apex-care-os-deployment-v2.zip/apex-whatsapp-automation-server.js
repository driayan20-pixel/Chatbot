"use strict";

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const CONFIG = {
  port: Number(process.env.PORT || 8080),
  clinicName: process.env.CLINIC_NAME || "Cabinet Dentaire Apex",
  doctorName: process.env.DOCTOR_NAME || "Dr WONE",
  staffWhatsappNumber: process.env.STAFF_WHATSAPP_NUMBER || "221787881111",
  bookingUrl: process.env.BOOKING_URL || "https://zcal.co/i/67Vb-8QG",
  verifyToken: process.env.WHATSAPP_VERIFY_TOKEN || "change-me",
  whatsappToken: process.env.WHATSAPP_ACCESS_TOKEN || "",
  whatsappPhoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || "",
  whatsappGraphVersion: process.env.WHATSAPP_GRAPH_VERSION || "v20.0",
  dataFile: path.resolve(process.cwd(), process.env.DATA_FILE || "apex-appointments.json"),
  recordsFile: path.resolve(process.cwd(), process.env.RECORDS_FILE || "apex-platform-records.json"),
  defaultConsultationAmount: Number(process.env.DEFAULT_CONSULTATION_AMOUNT || 15000),
  currency: process.env.CURRENCY || "XOF",
  publicBaseUrl: process.env.PUBLIC_BASE_URL || "https://api.votre-domaine.com",
  ownerAdminEmail: normalizeEmail(process.env.OWNER_ADMIN_EMAIL || "vous@cabinet-apex.sn"),
  adminApiToken: process.env.ADMIN_API_TOKEN || ""
};

let appointments = loadAppointments();
let records = loadRecords();

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "OPTIONS") {
      sendJson(res, 204, null);
      return;
    }

    if (req.method === "GET" && url.pathname === "/health") {
      sendJson(res, 200, { ok: true, service: "apex-whatsapp-automation" });
      return;
    }

    if (req.method === "GET" && url.pathname === "/webhook") {
      verifyWebhook(url, res);
      return;
    }

    if (req.method === "POST" && url.pathname === "/webhook") {
      const body = await readJson(req);
      const messages = extractWhatsAppMessages(body);
      await Promise.all(messages.map(handleWhatsAppMessage));
      sendJson(res, 200, { ok: true, received: messages.length });
      return;
    }

    if (req.method === "POST" && url.pathname === "/appointments") {
      const payload = await readJson(req);
      const appointment = createAppointment(payload);
      await notifyStaff(appointment);
      scheduleReminder(appointment);
      sendJson(res, 201, { ok: true, appointment });
      return;
    }

    if (req.method === "GET" && url.pathname === "/appointments") {
      sendJson(res, 200, { ok: true, appointments });
      return;
    }

    if (req.method === "GET" && url.pathname === "/stats") {
      sendJson(res, 200, { ok: true, stats: buildStats() });
      return;
    }

    if (req.method === "POST" && url.pathname === "/payments") {
      if (!records.botConfig.paymentRequired24h && !isAdminRequest(req)) {
        sendJson(res, 403, { ok: false, error: "payment_24h_disabled_by_admin" });
        return;
      }
      const payload = await readJson(req);
      const payment = createPayment(payload);
      await notifyPayment(payment);
      sendJson(res, 201, { ok: true, payment });
      return;
    }

    if (req.method === "POST" && url.pathname === "/intake") {
      const payload = await readJson(req);
      const intake = createIntake(payload);
      sendJson(res, 201, { ok: true, intake });
      return;
    }

    if (req.method === "POST" && url.pathname === "/calls") {
      const payload = await readJson(req);
      const call = createCallOrder(payload);
      await notifyCallOrder(call);
      sendJson(res, 201, { ok: true, call });
      return;
    }

    if (req.method === "GET" && url.pathname === "/bot-config") {
      sendJson(res, 200, { ok: true, botConfig: records.botConfig });
      return;
    }

    if (req.method === "PUT" && url.pathname === "/bot-config") {
      if (!requireAdmin(req, res)) return;
      const payload = await readJson(req);
      records.botConfig = createBotConfig(payload);
      addAudit("bot_config_updated", "Configuration chatbot mise a jour");
      saveRecords();
      sendJson(res, 200, { ok: true, botConfig: records.botConfig });
      return;
    }

    if (req.method === "GET" && url.pathname === "/admins") {
      if (!requireAdmin(req, res)) return;
      sendJson(res, 200, {
        ok: true,
        ownerAdminEmail: CONFIG.ownerAdminEmail,
        admins: records.admins
      });
      return;
    }

    if (req.method === "POST" && url.pathname === "/admins") {
      if (!requireAdmin(req, res)) return;
      const payload = await readJson(req);
      const admin = addAdmin(payload.email);
      sendJson(res, 201, { ok: true, admin, admins: records.admins });
      return;
    }

    if (req.method === "DELETE" && url.pathname.startsWith("/admins/")) {
      if (!requireAdmin(req, res)) return;
      const email = decodeURIComponent(url.pathname.replace("/admins/", ""));
      removeAdmin(email);
      sendJson(res, 200, { ok: true, admins: records.admins });
      return;
    }

    if (req.method === "POST" && url.pathname === "/subscriptions") {
      if (!requireAdmin(req, res)) return;
      const payload = await readJson(req);
      const subscription = createSubscription(payload);
      sendJson(res, 201, { ok: true, subscription });
      return;
    }

    if (req.method === "DELETE" && url.pathname === "/subscriptions/current") {
      if (!requireAdmin(req, res)) return;
      const subscription = cancelSubscription();
      sendJson(res, 200, { ok: true, subscription });
      return;
    }

    sendJson(res, 404, { ok: false, error: "not_found" });
  } catch (error) {
    console.error(error);
    sendJson(res, 500, { ok: false, error: "server_error" });
  }
});

server.listen(CONFIG.port, () => {
  console.log(`Apex automation server listening on http://localhost:${CONFIG.port}`);
  console.log(CONFIG.whatsappToken ? "WhatsApp Cloud API enabled" : "WhatsApp dry-run mode: missing access token");
});

function verifyWebhook(url, res) {
  const mode = url.searchParams.get("hub.mode");
  const token = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge");

  if (mode === "subscribe" && token === CONFIG.verifyToken && challenge) {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end(challenge);
    return;
  }

  sendJson(res, 403, { ok: false, error: "webhook_verification_failed" });
}

async function handleWhatsAppMessage(message) {
  const from = message.from;
  const text = message.text && message.text.body ? message.text.body : "";
  if (!from || !text) return;

  const answer = buildVirtualAnswer(text);
  await sendWhatsApp(from, answer);
}

function buildVirtualAnswer(text) {
  const normalized = normalize(text);

  if (hasAny(normalized, ["rdv", "rendez", "consultation", "reserver", "reservation"])) {
    return [
      `Bonjour, l'assistant virtuel du ${CONFIG.clinicName} peut vous aider a planifier votre consultation.`,
      `Agenda : ${CONFIG.bookingUrl}`,
      "Vous pouvez aussi envoyer votre nom, motif et creneau souhaite ici."
    ].join("\n");
  }

  if (hasAny(normalized, ["payer", "paiement", "wave", "orange money", "regler", "acompte"])) {
    return [
      `Le paiement de consultation peut etre demande par Wave ou Orange Money au moins 24h avant le rendez-vous.`,
      "L'assistant peut envoyer un lien securise, verifier le statut et relancer automatiquement si le paiement reste en attente.",
      "Envoyez votre nom et la date du rendez-vous pour preparer la demande."
    ].join("\n");
  }

  if (hasAny(normalized, ["appel", "appeler", "rappel vocal", "suivi"])) {
    return [
      "Je peux preparer un suivi patient par message ou par appel.",
      "Pour un appel, l'ordre doit etre valide par l'equipe du cabinet afin de proteger les donnees confidentielles."
    ].join("\n");
  }

  if (hasAny(normalized, ["urgence", "douleur", "gonfle", "abces", "saigne", "casse", "fracture"])) {
    return [
      "Pour une douleur forte, un gonflement, un traumatisme ou un saignement persistant, contactez directement l'equipe.",
      `WhatsApp cabinet : +${CONFIG.staffWhatsappNumber}`,
      "Cet assistant ne pose pas de diagnostic medical."
    ].join("\n");
  }

  if (hasAny(normalized, ["horaire", "ouvert", "samedi", "dimanche"])) {
    return "Horaires : lundi-vendredi 09:00-18:00, samedi 09:00-13:00, dimanche ferme.";
  }

  if (hasAny(normalized, ["adresse", "localisation", "maps", "venir"])) {
    return "Adresse : MGRQ+VQP Cabinet Dentaire Apex, Villa numero 2, Rue PE 17, Dakar.";
  }

  if (hasAny(normalized, ["prix", "tarif", "devis", "cout"])) {
    return "Pour un devis fiable, indiquez le soin souhaite et l'equipe vous orientera. Une consultation peut etre necessaire selon le cas.";
  }

  if (hasAny(normalized, ["implant", "orthodontie", "prothese", "detartrage", "soin"])) {
    return "Services : implantologie, orthodontie, soins generaux, prothese dentaire, detartrage et controles.";
  }

  return [
    `Bonjour, vous etes bien en contact avec l'assistant virtuel du ${CONFIG.clinicName}.`,
    "Je peux qualifier votre demande, creer une demande de rendez-vous, preparer une relance, repondre aux questions courantes ou alerter l'equipe en cas d'urgence dentaire."
  ].join("\n");
}

function createAppointment(payload) {
  const now = new Date();
  const slotDate = payload.slotISO ? new Date(payload.slotISO) : null;
  const slotISO = slotDate && !Number.isNaN(slotDate.getTime()) ? slotDate.toISOString() : "";
  const appointment = {
    id: `APX-${now.getTime().toString(36).toUpperCase()}`,
    createdAt: now.toISOString(),
    status: "requested",
    source: clean(payload.source || "site-chat-apex"),
    name: clean(payload.name),
    phone: normalizePhone(payload.phone),
    service: clean(payload.service),
    slotText: clean(payload.slotText || payload.slot),
    slotISO,
    reminderOptIn: payload.reminderOptIn !== false
  };

  appointments.push(appointment);
  saveAppointments();
  return appointment;
}

async function notifyStaff(appointment) {
  const message = [
    "Nouvelle demande de rendez-vous Apex",
    `Reference : ${appointment.id}`,
    `Patient : ${appointment.name || "A preciser"}`,
    `WhatsApp : ${appointment.phone || "A preciser"}`,
    `Motif : ${appointment.service || "A preciser"}`,
    `Creneau : ${appointment.slotText || appointment.slotISO || "A preciser"}`,
    `Relance : ${appointment.reminderOptIn ? "oui" : "non"}`
  ].join("\n");

  await sendWhatsApp(CONFIG.staffWhatsappNumber, message);
}

function scheduleReminder(appointment) {
  if (!appointment.reminderOptIn || !appointment.slotISO || !appointment.phone) return;

  const appointmentTime = new Date(appointment.slotISO).getTime();
  const reminderTime = appointmentTime - 24 * 60 * 60 * 1000;
  const delay = reminderTime - Date.now();

  if (delay <= 0 || delay > 2147483647) return;

  setTimeout(async () => {
    await sendWhatsApp(
      appointment.phone,
      `Rappel ${CONFIG.clinicName} : votre rendez-vous ${appointment.service || ""} est prevu demain. Reference ${appointment.id}.`
    );
  }, delay);
}

function createPayment(payload) {
  const now = new Date();
  const slotDate = payload.slotISO ? new Date(payload.slotISO) : null;
  const appointmentTime = slotDate && !Number.isNaN(slotDate.getTime()) ? slotDate.getTime() : 0;
  const latestPaymentTime = appointmentTime ? appointmentTime - 24 * 60 * 60 * 1000 : 0;
  const requestedDue = payload.dueAt ? new Date(payload.dueAt).getTime() : 0;
  const dueAt = latestPaymentTime
    ? new Date(requestedDue && requestedDue <= latestPaymentTime ? requestedDue : latestPaymentTime)
    : new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const method = normalizePaymentMethod(payload.method);
  const payment = {
    id: `PAY-${now.getTime().toString(36).toUpperCase()}`,
    createdAt: now.toISOString(),
    status: "pending",
    method,
    amount: Number(payload.amount || CONFIG.defaultConsultationAmount),
    currency: CONFIG.currency,
    patientName: clean(payload.name || payload.patientName),
    patientPhone: normalizePhone(payload.phone || payload.patientPhone),
    appointmentId: clean(payload.appointmentId),
    appointmentSlotISO: appointmentTime ? new Date(appointmentTime).toISOString() : "",
    dueAt: dueAt.toISOString(),
    paymentUrl: `${CONFIG.publicBaseUrl.replace(/\/$/, "")}/pay/${method.toLowerCase().replace(/\s+/g, "-")}/${now.getTime().toString(36)}`
  };

  records.payments.push(payment);
  addAudit("payment_created", `Paiement ${payment.method} cree pour ${payment.patientName || "patient"}`);
  saveRecords();
  return payment;
}

async function notifyPayment(payment) {
  if (!payment.patientPhone) return;
  const message = [
    `Bonjour ${payment.patientName || ""}, votre consultation au ${CONFIG.clinicName} doit etre payee au moins 24h avant le rendez-vous.`,
    `Montant : ${payment.amount} ${payment.currency}`,
    `Methode : ${payment.method}`,
    `Lien securise : ${payment.paymentUrl}`,
    `Echeance : ${payment.dueAt}`
  ].join("\n");
  await sendWhatsApp(payment.patientPhone, message);
}

function createIntake(payload) {
  const now = new Date();
  const intake = {
    id: `INT-${now.getTime().toString(36).toUpperCase()}`,
    createdAt: now.toISOString(),
    patientName: clean(payload.name || payload.patientName),
    phone: normalizePhone(payload.phone),
    reason: clean(payload.reason),
    painLevel: clean(payload.painLevel),
    details: cleanLong(payload.details),
    whatsappConsent: payload.whatsappConsent !== false,
    callConsent: payload.callConsent === true,
    status: shouldEscalate(payload) ? "needs_human_review" : "triaged"
  };

  records.intakes.push(intake);
  addAudit("intake_created", `Formulaire patient ${intake.status}`);
  saveRecords();
  return intake;
}

function createCallOrder(payload) {
  const now = new Date();
  const call = {
    id: `CALL-${now.getTime().toString(36).toUpperCase()}`,
    createdAt: now.toISOString(),
    status: "ordered",
    patientName: clean(payload.name || payload.patientName),
    phone: normalizePhone(payload.phone),
    reason: clean(payload.reason),
    priority: clean(payload.priority || "Normale"),
    script: cleanLong(payload.script),
    orderedBy: clean(payload.orderedBy || "cabinet-admin"),
    humanApproved: payload.humanApproved !== false
  };

  records.calls.push(call);
  addAudit("call_ordered", `Ordre d'appel ${call.priority} pour ${call.patientName || "patient"}`);
  saveRecords();
  return call;
}

async function notifyCallOrder(call) {
  const message = [
    "Ordre d'appel patient Apex",
    `Reference : ${call.id}`,
    `Patient : ${call.patientName || "A preciser"}`,
    `Telephone : ${call.phone || "A preciser"}`,
    `Motif : ${call.reason || "A preciser"}`,
    `Priorite : ${call.priority}`,
    `Validation humaine : ${call.humanApproved ? "oui" : "non"}`
  ].join("\n");
  await sendWhatsApp(CONFIG.staffWhatsappNumber, message);
}

function createBotConfig(payload) {
  return {
    updatedAt: new Date().toISOString(),
    publicName: clean(payload.publicName || "Assistant Apex"),
    tone: clean(payload.tone || "Rassurant et professionnel"),
    languages: clean(payload.languages || "Francais + Wolof simple"),
    emergencyEscalation: clean(payload.emergencyEscalation || "WhatsApp equipe"),
    paymentRequired24h: payload.paymentRequired24h !== false,
    automaticReminders: payload.automaticReminders !== false,
    callsRequireHumanOrder: payload.callsRequireHumanOrder !== false,
    medicalDisclaimer: payload.medicalDisclaimer !== false,
    instructions: cleanLong(payload.instructions || "Ne jamais diagnostiquer. Escalader les urgences et collecter uniquement les informations utiles.")
  };
}

function createSubscription(payload) {
  const now = new Date();
  const subscription = {
    id: `SUB-${now.getTime().toString(36).toUpperCase()}`,
    createdAt: now.toISOString(),
    status: "active",
    plan: clean(payload.plan || "Cabinet Pro"),
    clinicName: clean(payload.clinicName || CONFIG.clinicName),
    billingPhone: normalizePhone(payload.billingPhone || CONFIG.staffWhatsappNumber),
    seats: Number(payload.seats || 3)
  };

  records.subscription = subscription;
  addAudit("subscription_active", `Abonnement ${subscription.plan} active`);
  saveRecords();
  return subscription;
}

function cancelSubscription() {
  const now = new Date();
  const current = records.subscription || {};
  const subscription = {
    ...current,
    status: "cancelled",
    cancelledAt: now.toISOString(),
    exportAvailable: true
  };
  records.subscription = subscription;
  addAudit("subscription_cancelled", "Desabonnement demande, export disponible");
  saveRecords();
  return subscription;
}

function buildStats() {
  const paid = records.payments.filter((payment) => payment.status === "paid").length;
  return {
    appointments: appointments.length,
    payments: records.payments.length,
    paymentsPaid: paid,
    paymentsPending: records.payments.length - paid,
    intakes: records.intakes.length,
    callOrders: records.calls.length,
    activeSubscription: records.subscription && records.subscription.status === "active",
    auditEvents: records.audit.length,
    botConfig: records.botConfig
  };
}

function requireAdmin(req, res) {
  if (isAdminRequest(req)) return true;
  sendJson(res, 403, {
    ok: false,
    error: "admin_required",
    message: "Cette action est reservee au proprietaire ou a un administrateur autorise."
  });
  return false;
}

function isAdminRequest(req) {
  const email = normalizeEmail(req.headers["x-admin-email"]);
  const token = String(req.headers["x-admin-token"] || "");
  const tokenOk = !CONFIG.adminApiToken || token === CONFIG.adminApiToken;
  return tokenOk && getAdminEmails().includes(email);
}

function getAdminEmails() {
  return Array.from(new Set([CONFIG.ownerAdminEmail, ...records.admins.map(normalizeEmail)].filter(Boolean)));
}

function addAdmin(email) {
  const normalized = normalizeEmail(email);
  if (!normalized || !normalized.includes("@")) {
    throw new Error("invalid_admin_email");
  }
  if (normalized === CONFIG.ownerAdminEmail) {
    return { email: normalized, role: "owner" };
  }
  if (!records.admins.includes(normalized)) {
    records.admins.push(normalized);
    addAudit("admin_added", `Administrateur ajoute : ${normalized}`);
    saveRecords();
  }
  return { email: normalized, role: "admin" };
}

function removeAdmin(email) {
  const normalized = normalizeEmail(email);
  records.admins = records.admins.filter((item) => item !== normalized && item !== CONFIG.ownerAdminEmail);
  addAudit("admin_removed", `Administrateur retire : ${normalized}`);
  saveRecords();
}

async function sendWhatsApp(to, body) {
  const cleanTo = normalizePhone(to);
  if (!cleanTo || !body) return { ok: false, skipped: true };

  if (!CONFIG.whatsappToken || !CONFIG.whatsappPhoneNumberId) {
    console.log(`[dry-run WhatsApp] to=${cleanTo}\n${body}\n`);
    return { ok: true, dryRun: true };
  }

  const endpoint = `https://graph.facebook.com/${CONFIG.whatsappGraphVersion}/${CONFIG.whatsappPhoneNumberId}/messages`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${CONFIG.whatsappToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: cleanTo,
      type: "text",
      text: {
        preview_url: false,
        body
      }
    })
  });

  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("WhatsApp API error", response.status, result);
  }
  return result;
}

function extractWhatsAppMessages(body) {
  const entries = Array.isArray(body.entry) ? body.entry : [];
  return entries.flatMap((entry) => {
    const changes = Array.isArray(entry.changes) ? entry.changes : [];
    return changes.flatMap((change) => {
      const value = change.value || {};
      return Array.isArray(value.messages) ? value.messages : [];
    });
  });
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
      if (data.length > 1_000_000) {
        req.destroy();
        reject(new Error("payload_too_large"));
      }
    });
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (error) {
        reject(error);
      }
    });
    req.on("error", reject);
  });
}

function sendJson(res, status, payload) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Admin-Email, X-Admin-Token",
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
  };
  res.writeHead(status, headers);
  if (status === 204) {
    res.end();
    return;
  }
  res.end(JSON.stringify(payload));
}

function loadAppointments() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG.dataFile, "utf8"));
  } catch {
    return [];
  }
}

function saveAppointments() {
  fs.writeFileSync(CONFIG.dataFile, JSON.stringify(appointments, null, 2));
}

function loadRecords() {
  try {
    return withRecordDefaults(JSON.parse(fs.readFileSync(CONFIG.recordsFile, "utf8")));
  } catch {
    return withRecordDefaults({});
  }
}

function saveRecords() {
  fs.writeFileSync(CONFIG.recordsFile, JSON.stringify(records, null, 2));
}

function withRecordDefaults(value) {
  return {
    payments: Array.isArray(value.payments) ? value.payments : [],
    intakes: Array.isArray(value.intakes) ? value.intakes : [],
    calls: Array.isArray(value.calls) ? value.calls : [],
    admins: Array.isArray(value.admins)
      ? Array.from(new Set(value.admins.map(normalizeEmail).filter((email) => email && email !== CONFIG.ownerAdminEmail)))
      : [],
    audit: Array.isArray(value.audit) ? value.audit : [],
    subscription: value.subscription || {
      status: "trial",
      plan: "Cabinet Pro",
      startedAt: new Date().toISOString()
    },
    botConfig: value.botConfig || createBotConfig({})
  };
}

function addAudit(type, message) {
  records.audit.unshift({
    id: `AUD-${Date.now().toString(36).toUpperCase()}`,
    at: new Date().toISOString(),
    type,
    message: cleanLong(message)
  });
  records.audit = records.audit.slice(0, 500);
}

function normalize(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function hasAny(text, words) {
  return words.some((word) => text.includes(normalize(word)));
}

function clean(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 180);
}

function cleanLong(value) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, 1200);
}

function normalizePhone(value) {
  const digits = String(value || "").replace(/[^\d]/g, "");
  if (!digits) return "";
  if (digits.startsWith("00")) return digits.slice(2);
  return digits;
}

function normalizePaymentMethod(value) {
  const normalized = normalize(value);
  if (normalized.includes("orange")) return "Orange Money";
  return "Wave";
}

function shouldEscalate(payload) {
  const text = normalize(`${payload.reason || ""} ${payload.painLevel || ""} ${payload.details || ""}`);
  return hasAny(text, ["urgence", "forte", "9", "10", "gonfle", "fievre", "saignement", "traumatisme", "abces"]);
}
