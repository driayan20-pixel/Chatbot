# Chat Apex Dr WONE - guide d'integration

## Livrables

- `apex-chat-widget.html` : assistant virtuel patient pret a tester dans un navigateur. Il gere les demandes courantes, rendez-vous, urgences, devis, horaires, adresse, relances et transfert WhatsApp.
- `apex-virtual-assistant-platform.html` : interface SaaS complete avec experience patient, dashboard, paiements, administration chatbot, abonnement et securite.
- `apex-whatsapp-automation-server.js` : passerelle technique pour brancher WhatsApp Business Cloud API, recevoir les messages, creer des demandes de rendez-vous et notifier l'equipe.
- `apex-logo.png` : logo officiel du Cabinet Dentaire Apex repris depuis le site du cabinet.

## Informations cabinet utilisees

- Cabinet : Cabinet Dentaire Apex, Dr WONE, Dakar
- WhatsApp / telephone : +221 78 788 11 11
- Email : cabinetdentaireapex@gmail.com
- Adresse : MGRQ+VQP Cabinet Dentaire Apex, Villa numero 2, Rue PE 17, Dakar
- Horaires : lundi-vendredi 09:00-18:00, samedi 09:00-13:00, dimanche ferme
- Services : implantologie, orthodontie, soins generaux, prothese dentaire, detartrage, controle

## Integration sur le site

Le fichier HTML contient deja le chat en mode page complete. Pour l'integrer comme bulle flottante sur le site Apex, isoler le contenu CSS/JS du fichier puis lancer :

```html
<script src="/apex-chat-widget.js"></script>
<script>
  window.ApexDentalChat.enableFloating();
</script>
```

Parametres importants dans le script :

```js
window.ApexDentalChat.config.whatsappNumber = "221787881111";
window.ApexDentalChat.config.bookingUrl = "https://zcal.co/i/67Vb-8QG";
window.ApexDentalChat.config.apiBase = "https://api.votre-domaine.com";
```

`apiBase` reste vide pour une demonstration simple. Une fois le serveur deploye, le widget envoie automatiquement les demandes a `/appointments`.

## WhatsApp Business

Pour automatiser les messages WhatsApp, le cabinet doit utiliser WhatsApp Business Cloud API ou un prestataire connecte a l'API officielle. Les variables a configurer sur le serveur :

```bash
PORT=8080
OWNER_ADMIN_EMAIL=votre-email-admin@domaine.com
ADMIN_API_TOKEN=un-token-admin-long-et-prive
WHATSAPP_VERIFY_TOKEN=un-token-prive
WHATSAPP_ACCESS_TOKEN=token-meta
WHATSAPP_PHONE_NUMBER_ID=id-du-numero-meta
WHATSAPP_GRAPH_VERSION=version-graph-active
STAFF_WHATSAPP_NUMBER=221787881111
BOOKING_URL=https://zcal.co/i/67Vb-8QG
```

Le webhook Meta doit pointer vers :

```text
https://api.votre-domaine.com/webhook
```

Le serveur fournit aussi :

- `GET /health` pour verifier que le service repond
- `POST /appointments` pour recevoir une demande depuis le chat
- `GET /appointments` pour consulter les demandes enregistrees
- `GET /stats` pour alimenter le dashboard
- `POST /payments` pour creer une demande de paiement Wave ou Orange Money
- `POST /intake` pour recevoir le formulaire detaille patient
- `POST /calls` pour creer un ordre d'appel patient valide par le cabinet
- `GET /bot-config` et `PUT /bot-config` pour administrer le chatbot
- `GET /admins` pour consulter le proprietaire et les administrateurs
- `POST /admins` pour ajouter un administrateur par email
- `DELETE /admins/:email` pour retirer un administrateur
- `POST /subscriptions` pour activer un abonnement
- `DELETE /subscriptions/current` pour gerer le desabonnement
- `GET /webhook` et `POST /webhook` pour WhatsApp

Les routes sensibles doivent etre appelees avec :

```http
X-Admin-Email: votre-email-admin@domaine.com
X-Admin-Token: un-token-admin-long-et-prive
```

## Proprietaire et administrateurs

Le proprietaire de la plateforme est defini par `OWNER_ADMIN_EMAIL`. C'est le super-admin.

Il peut ajouter d'autres administrateurs depuis le dashboard en renseignant leur email, comme sur une fiche Google Business.

Actions reservees au super-admin ou aux admins :

- modifier la configuration du chatbot
- activer ou desactiver le paiement de consultation 24h avant
- ajouter ou retirer un administrateur
- gerer l'abonnement
- demander l'export ou le desabonnement
- donner un ordre d'appel patient

L'option `paymentRequired24h` dans `/bot-config` controle l'affichage et l'utilisation du paiement cote patient.

## Automatisation des rendez-vous

Role du chatbot :

- agir comme assistant virtuel avant l'intervention humaine
- qualifier le motif de consultation
- collecter les informations utiles au secretariat
- automatiser les confirmations et relances
- repondre aux questions simples sans saturer WhatsApp
- transferer les urgences, devis sensibles et cas medicaux vers l'equipe

Flux recommande :

1. Le patient choisit "Prendre rendez-vous" dans le chat.
2. Le chat collecte nom, WhatsApp, motif, creneau souhaite et accord de relance.
3. La demande est envoyee a `/appointments`.
4. L'equipe recoit une notification WhatsApp avec la reference Apex.
5. Une confirmation est envoyee au patient apres validation du creneau.
6. Les relances sont envoyees automatiquement : confirmation immediate, J-1, matin du rendez-vous, suivi apres soin, rendez-vous manque.

Pour une automatisation complete de l'agenda, connecter ensuite zcal, Google Calendar ou l'outil de rendez-vous choisi au serveur via webhook/API.

## Paiement 24h avant

Le patient peut recevoir une demande de paiement de consultation par Wave ou Orange Money au moins 24h avant le rendez-vous.

Flux recommande :

1. Le rendez-vous est demande ou confirme.
2. Le serveur cree une reference de paiement via `POST /payments`.
3. Le patient recoit un lien ou une instruction Wave/Orange Money.
4. Le statut passe a `pending`, puis `paid` apres confirmation du prestataire.
5. Si le paiement reste en attente, l'assistant relance le patient avant l'echeance.
6. Le cabinet voit le statut dans le dashboard.

La version fournie simule le lien de paiement. En production, il faudra connecter le compte marchand Wave, Orange Money ou un agregateur local compatible, puis verifier les statuts par webhook.

Le paiement 24h avant est une option admin-only. Si elle est desactivee, l'assistant ne propose pas le paiement au patient et `POST /payments` refuse les demandes non admin.

## Deploiement

Architecture recommandee :

- Frontend statique : `apex-virtual-assistant-platform.html`, `apex-chat-widget.html`, `apex-logo.png`
- API Node : `apex-whatsapp-automation-server.js`
- Domaine : `assistant.votre-domaine.com`
- API : `api.votre-domaine.com`
- HTTPS obligatoire

Etapes :

1. Deployer les fichiers HTML/PNG sur l'hebergement web.
2. Deployer `apex-whatsapp-automation-server.js` sur un serveur Node.
3. Configurer les variables d'environnement admin, WhatsApp, paiement et domaine.
4. Brancher le webhook WhatsApp Business sur `/webhook`.
5. Brancher Wave/Orange Money ou l'agregateur choisi sur `/payments`.
6. Activer le paiement 24h dans le dashboard uniquement avec un compte admin.
7. Tester un RDV, un paiement, une relance, un formulaire patient et un ordre d'appel.

## Dashboard SaaS et abonnement

La plateforme est pensee pour etre vendue sous forme d'abonnement mensuel :

- suivi des demandes patient
- taux de rendez-vous confirmes
- paiements en attente ou valides
- temps gagne par le cabinet
- motifs les plus frequents
- patients a traiter en priorite
- administration du chatbot
- activation, changement d'offre, suspension et desabonnement
- export des donnees en cas de desabonnement

Les offres proposees dans le prototype sont indicatives : Starter, Cabinet Pro et Premium.

## Appels de suivi

L'assistant peut creer un ordre d'appel patient via `POST /calls`, mais l'appel automatique doit rester soumis a une validation humaine du cabinet.

En production, brancher un fournisseur vocal et conserver :

- nom du patient
- numero appele
- motif de l'appel
- script valide
- responsable ayant donne l'ordre
- date, statut et resultat de l'appel

## Securite et confidentialite

Les donnees patient et les informations de paiement doivent etre traitees avec un niveau de securite eleve :

- HTTPS/TLS obligatoire
- chiffrement des donnees sensibles au repos
- gestion des roles : proprietaire, praticien, secretariat, support
- journal d'audit pour lectures, modifications, paiements et appels
- consentement explicite pour WhatsApp, relances et appels
- collecte minimale des informations utiles
- sauvegardes chiffrees et procedure d'export/suppression
- secrets API hors du code source

## Reponses virtuelles incluses

Le bot sait orienter les demandes sur :

- prise de rendez-vous
- paiement de consultation 24h avant par Wave ou Orange Money
- modification ou annulation
- urgence dentaire avec redirection vers l'equipe
- horaires, adresse et Maps
- services du cabinet
- tarifs et devis
- relances et confirmations
- suivi post-soin et ordre d'appel valide par le cabinet
- transfert humain vers WhatsApp

Il ne pose pas de diagnostic medical. Les douleurs fortes, gonflements, traumatismes, saignements persistants ou fievres sont rediriges vers l'equipe.

## Messages types

Confirmation :

```text
Bonjour [Prenom], votre demande de rendez-vous au Cabinet Dentaire Apex est bien recue. Reference : [REF]. L'equipe revient vers vous pour confirmer le creneau.
```

Rappel J-1 :

```text
Bonjour [Prenom], rappel Cabinet Dentaire Apex : votre rendez-vous est prevu demain a [HEURE]. Repondez OUI pour confirmer ou MODIFIER pour demander un autre creneau.
```

Suivi apres soin :

```text
Bonjour [Prenom], le Cabinet Dentaire Apex espere que vous allez bien apres votre soin. En cas de douleur inhabituelle ou de question, repondez a ce message.
```

Rendez-vous manque :

```text
Bonjour [Prenom], nous avons note votre absence au rendez-vous Apex. Souhaitez-vous reprogrammer un creneau cette semaine ?
```
